"""Single source of truth for the application version reported by the API and shown in the interface."""
APP_VERSION = "8.2"
